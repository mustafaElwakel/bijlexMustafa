import React, { useRef, useState, useEffect } from 'react';
import Chart from 'chart.js/auto';

const App = () => {
  const graphRef = useRef(null);
  const [data, setData] = useState([]);
  const [addPoints, setAddPoints] = useState(true);
  const [addLine, setAddLine] = useState(false);
  const [lineData, setLineData] = useState([]);
  const [selectedPoint, setSelectedPoint] = useState(null);

  useEffect(() => {
    if (graphRef.current) {
      const ctx = graphRef.current.getContext('2d');
      const chart = new Chart(ctx, {
        type: 'scatter',
        data: {
          datasets: [{
            label: 'User points',
            data: data,
            backgroundColor: 'red'
          },
          {
            label: 'User line',
            data: lineData,
            showLine: true,
            fill: false,
            borderColor: 'blue'
          }]
        },
        options: {
          scales: {
            x: {
              type: 'linear',
              position: 'center',
              min: -10,
              max: 10,
              ticks: {
                stepSize: 1,
                precision: 0
              },
              title: {
                display: true,
                text: 'X Axis'
              }
            },
            y: {
              type: 'linear',
              position: 'center',
              min: -10,
              max: 10,
              ticks: {
                stepSize: 1,
                precision: 0
              },
              title: {
                display: true,
                text: 'Y Axis'
              }
            }
          },
          plugins: {
            legend: {
              display: true,
              position: 'bottom',
            }
          },
          interaction: {
            mode: 'point'
          }
        }
      });

      const handleClick = (e) => {
        const rect = graphRef.current.getBoundingClientRect();
        let x = ((e.clientX - rect.left) / rect.width) * 20 - 10; // Convert pixel coordinates to chart coordinates
        let y = ((rect.bottom - e.clientY) / rect.height) * 20 - 10; // Convert pixel coordinates to chart coordinates
        x = Math.round(x);
        y = Math.round(y);
        if (y < 0 ){
          y = ((rect.bottom - e.clientY) / rect.height) * 20 - 12;
          y = Math.round(y);
        };
      
        if (addPoints) {
          setData(oldData => [...oldData, { x, y }]);
        }
        if (addLine) {
          console.log(x,y);

          setLineData(oldData => {
            // If there are already two points, start a new line
            if (selectedPoint) {
              return [...oldData, { x, y }];
            } else {
              // Otherwise, add the point to the existing line
              return [...oldData, { x, y }];
            }
            
          });
        }
      };
      

      graphRef.current.addEventListener('click', handleClick);

      return () => {
        chart.destroy();
        graphRef.current.removeEventListener('click', handleClick);
      };
    }
  }, [data, addPoints, lineData, addLine]); 

  return (
    <div>
      <div
        style={{
          width: '500px',
          height: '500px',
          position: 'relative',
          border: '1px solid #ccc',
        }}
      >
        <canvas ref={graphRef} />
      </div>
      <button 
        onClick={() => {
          setAddPoints(!addPoints);
          if (addPoints) {
            setAddLine(false);
          }
        }}
        style={{backgroundColor: addPoints ? 'lightgreen' : 'white'}}
      >
        {addPoints ? 'Disable Adding Points' : 'Enable Adding Points'}
      </button>

      <button 
        onClick={() => {
          setAddLine(!addLine);
          if (addLine) {
            setAddPoints(false);
          }
        }}
        style={{backgroundColor: addLine ? 'lightgreen' : 'white'}}
      >
        {addLine ? 'Disable Adding Line' : 'Enable Adding Line'}
      </button>
     
    </div>
  );
};

export default App;
