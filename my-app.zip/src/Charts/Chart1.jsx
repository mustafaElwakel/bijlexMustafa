import React, { useRef, useState, useEffect } from 'react';
import Chart from 'chart.js/auto';

const App = () => {
  const graphRef = useRef(null);
 
  useEffect(() => {
    if (graphRef.current) {
      const ctx = graphRef.current.getContext('2d');
      const chart = new Chart(ctx, {
        type: 'line',
        data: {
        },
        options: {
          scales: {
            x: {
              type: 'linear',
              position: 'center',
              min: -10,
              max: 10,
              ticks: {
                stepSize: 1,
                precision: 0
              },
              title: {
                display: true,
              }
            },
            y: {
              type: 'linear',
              position: 'center',
              min: -10,
              max: 10,
              ticks: {
                stepSize: 1,
                precision: 0
              },
              title: {
                display: true,
              }
            }
          },
          plugins: {
            legend: {
              display: true,
              position: 'bottom',
            }
          },
          interaction: {
            mode: 'point'
          }
        }
      });

    
      return () => {
        chart.destroy();
      };
    }
  },); // Reinitialize chart when slope, intercept, or dragging state changes


  return (
    <div>
      <div
        style={{
          width: '500px',
          height: '500px',
          position: 'relative',
          border: '1px solid #ccc',
        }}
      >
        <canvas ref={graphRef} />
      </div>

     
    </div>
  );
};

export default App;
