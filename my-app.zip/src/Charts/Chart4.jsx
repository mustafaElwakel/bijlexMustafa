import React, { useRef, useState, useEffect } from 'react';
import Chart from 'chart.js/auto';
import debounce from 'lodash.debounce';
const App = () => {
  const graphRef = useRef(null);
  const [slope, setSlope] = useState(1); // Default slope
  const [intercept, setIntercept] = useState(0); // Default y-intercept
  const [dragging, setDragging] = useState(false); // State to track whether we're currently dragging

  useEffect(() => {
    if (graphRef.current) {
      const ctx = graphRef.current.getContext('2d');
      const chart = new Chart(ctx, {
        type: 'line',
        data: {
          labels: [],
          datasets: [{
            label: 'z',
            borderColor: 'green', // Initial color
            data: [{ x: -10, y: calculateLineY(-10) }, { x: 10, y: calculateLineY(10) }],
            fill: false,
            borderWidth: 2,
          }]
        },
        options: {
          scales: {
            x: {
              type: 'linear',
              position: 'center',
              min: -10,
              max: 10,
              ticks: {
                stepSize: 1,
                precision: 0
              },
              title: {
                display: true,
                text: 'X Axis'
              }
            },
            y: {
              type: 'linear',
              position: 'center',
              min: -10,
              max: 10,
              ticks: {
                stepSize: 1,
                precision: 0
              },
              title: {
                display: true,
                text: 'Y Axis'
              }
            }
          },
          plugins: {
            legend: {
              display: true,
              position: 'bottom',
            }
          },
          interaction: {
            mode: 'point'
          }
        }
      });

      const handleMouseDown = (e) => {
        setDragging(true);
      };

      const handleMouseUp = (e) => {
        setDragging(false);
      };
      const x =  debounce((e)=>{
        const rect = graphRef.current.getBoundingClientRect();
        const y = e.clientY - rect.top;
        const newIntercept = (0.5 - y / rect.height) * 20; // Convert pixel coordinates to chart coordinates
        setIntercept(newIntercept);
      }, 1000,)

      const handleMouseMove = (e) => {
        if (dragging) {

            x(e);
        }
      };

      graphRef.current.addEventListener('mousedown', handleMouseDown);
      graphRef.current.addEventListener('mouseup', handleMouseUp);
      graphRef.current.addEventListener('mousemove', handleMouseMove);

      return () => {
        chart.destroy();
        graphRef.current.removeEventListener('mousedown', handleMouseDown);
        graphRef.current.removeEventListener('mouseup', handleMouseUp);
        graphRef.current.removeEventListener('mousemove', handleMouseMove);
      };
    }
  }, [slope, intercept, dragging]); // Reinitialize chart when slope, intercept, or dragging state changes

  const calculateLineY = (x) => {
    return slope * x + intercept;
  };

  return (
    <div>
      <div
        style={{
          width: '500px',
          height: '500px',
          position: 'relative',
          border: '1px solid #ccc',
        }}
      >
        <canvas ref={graphRef} />
      </div>

      <div>
        <label htmlFor='slope'>Slope (m): </label>
        <input
          type='number'
          id='slope'
          value={slope}
          onChange={(e) => setSlope(parseFloat(e.target.value))}
        />
      </div>

      <div>
        <label htmlFor='intercept'>Y-Intercept (b): </label>
        <input
          type='number'
          id='intercept'
          value={intercept}
          onChange={(e) => setIntercept(parseFloat(e.target.value))}
        />
      </div>
    </div>
  );
};

export default App;
