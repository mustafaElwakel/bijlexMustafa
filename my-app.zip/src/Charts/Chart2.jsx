import React, { useRef, useState, useEffect } from 'react';
import Chart from 'chart.js/auto';

const App = () => {
  const graphRef = useRef(null);
  const [intercept, setIntercept] = useState(1); // Default y-intercept

  useEffect(() => {
    if (graphRef.current) {
      const ctx = graphRef.current.getContext('2d');
      const chart = new Chart(ctx, {
        type: 'line',
        data: {
          labels: [],
          datasets: [{
            label: 'Line',
            borderColor: 'green', // Initial color
            data: [{ x: -10, y: calculateLineY(-10) }, { x: 10, y: calculateLineY(10) }],
            fill: false,
            borderWidth: 2,
          }]
        },
        options: {
          scales: {
            x: {
              type: 'linear',
              position: 'center',
              min: -10,
              max: 10,
              ticks: {
                stepSize: 1,
                precision: 0
              },
              title: {
                display: true,
                text: 'X Axis'
              }
            },
            y: {
              type: 'linear',
              position: 'center',
              min: -10,
              max: 10,
              ticks: {
                stepSize: 1,
                precision: 0
              },
              title: {
                display: true,
                text: 'Y Axis'
              }
            }
          },
          plugins: {
            legend: {
              display: true,
              position: 'bottom',
            }
          },
          interaction: {
            mode: 'point'
          }
        }
      });

      return () => {
        chart.destroy();
      };
    }
  }, [intercept]); // Reinitialize chart when intercept changes

  const calculateLineY = (x) => {
    return 2 * x + intercept; // Slope is fixed at 2
  };

  const moveLineUp = () => {
    setIntercept(intercept + 1);
  };

  const moveLineDown = () => {
    setIntercept(intercept - 1);
  };

  return (
    <div>
      <div
        style={{
          width: '500px',
          height: '500px',
          position: 'relative',
          border: '1px solid #ccc',
        }}
      >
        <canvas ref={graphRef} />
      </div>
      <button onClick={moveLineUp}>Move Line Up</button>
      <button onClick={moveLineDown}>Move Line Down</button>
    </div>
  );
};

export default App;
